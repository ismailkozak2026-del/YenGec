=====================================================
YENGEC AI - ANDROID APK DERLEME REHBERI
=====================================================

Bu proje, YenGec AI uygulamasinin tam Android Studio yerel kaynak kodlarini icerir.

1 DAKIKADA .APK DOSYASINI CIKARMA:
-----------------------------------------------------
1. Bilgisayarinizda Android Studio programini acin.
2. "Open Existing Project" secenegine tiklayip bu klasoru secin.
3. Android Studio projeyi acinca ust menuden:
   -> Build > Build Bundle(s) / APK(s) > Build APK(s) secenegine tiklayin.
4. Sag altta "APK(s) generated successfully" bildirimi cikacaktir.
5. "locate" butonuna bastiginizda dogrudan telefonunuza yukleyebileceginiz
   "app-debug.apk" dosyasini elde etmis olursunuz!

TELEFONA KURULUM:
-----------------------------------------------------
Olusan "app-debug.apk" dosyasini WhatsApp, Telegram veya kablo ile telefonunuza atip
uzerine tiklayarak aninda yukleyebilirsiniz!
